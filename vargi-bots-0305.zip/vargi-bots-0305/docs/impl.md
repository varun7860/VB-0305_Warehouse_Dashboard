# Implementation

Implementation of this project is achieved by combining Concepts of ROS and IOT together.
So the implementation is divided into two sections : 1. ROS  2. IOT
<br>
## ROS(Robot Operating System)

ROS Consists of multiple nodes running in parallel to achieve the desired solution. Using ros we created 4 nodes
for dispatching and shipping of orders

- ROS-IOT Bridge 
- Ur5-1 
- UR5-2
- Conveyor


<br>

The function of each node in detail is explained below.

### 1. ROS-IOT Bridge Node

- IOT-ROS bridge efficiently allows IOT-ROS communication.
- It Receives incoming orders via topic >> `/eyrc/vb/ACEGWXYZ/orders`, converts them
  in MQTT message format and publishes the message on topic >> `/ros_iot_bridge/mqtt/sub`
- It receives messages from ros nodes UR5-1 and UR5-2 and uses them to make HTTP Requests and 
  pushing data into the spreadsheets.
- All the spreadsheets such as IncomingOrders, Inventory, OrdersDispatched and OrdersShipped are updated here.
<br>

### 2. UR5-1 Node
- Receives the incoming Orders via topic >> `/ros_iot_bridge/mqtt/sub` 
- After the order is received a proper arranged dictionary of order details is made within the node to keep track of the orders. Then
  it checks for Higher priority orders. If HP orders are not present then it checks for medium priority or MP orders.Finally it checks for
  Low priority orders that are available.
- After the order is choosen then ur5 chooses the desired package to pick from the shelf. By image processing all the properties of package
  like its colour and QR code is extracted and saved. Then it picks up the package using joint angles and predefined poses and places
  it on the shelf.
- Finally it sends the request to update the dispatch orders sheets to ROS-IOT bridge through topic `/eyrc/vb/ACEGWXYZ/ros_to_iot` after 
  dispatching the particular package.
<br>

### 3. Conveyor Node 
- This node is used for sending package from ur5-1 node to ur5-2 node.
- This node is subscribed to a topic called `/ur5_1/package/place/response` to receive messages from ur5
- When the message of "Detached_Package" is received the belt is started.
- When the package reaches towards the side of ur5-2 the belt is stopped.
<br>

### 4. UR5-2 Node

- Receives the message containing package details through the topic >> `/ur5_1/package/details`
- The message contains following details:
    - Colour of the package
    - Priority
    - order id
    - city
    - item
    - quantity
    - cost
- As soon as valid message is received the node uses Frame transformation to find the location of package with respect to ur5-2 frame
  and then picks up the package.
- It then uses the ur5_1 message to place the package in the respective bin ( Red package in red bin, Green package in green bin and 
  yellow package in yellow bin) using cartesian translation.
- Finally, it sends the request to ROS-IOT bridge node for updating the shipped orders spreadsheet.
<br><br>

## IOT

IOT sections consists of Google app scripts , IOT module, google sheets and warehouse dashboard.

- IOT Module: This module is imported by ROS-IOT bridge node to Make HTTP requests and mqtt clients.
- Google app scripts : Email alerts are sent using google app scripts when data is pushed into spreadsheets. If data is pushed into dispatched
                       orders sheet then email alert with subject "Your order is dispatched" is sent to the customer. This process is same 
                       shipping of orders as well.
- Google sheets : Google sheets are updated using RS-IOT Bridge when it receives request from ros nodes.
- Warehouse dasboard : This is updated when dasboard sheet is filled with data. It shows order status and all the graphs related to it. In 
                       short this is the graphical representation of the order on the website.
<br><br>

## Working : Step by Step

<br>

![alt text](rosgraph.png)

<br>



- Step 1: ROS-IOT Bridge receives the order and publishes it on topic `/ros_iot_bridge/mqtt/sub`
- Step 2: Ur5-1 receives the order through `/ros_iot_bridge/mqtt/sub` chooses the order according to its priority.
- step 3 : Ur5-1 picks up the order from the shelf and places it on belt. It sends request to ROS-IOT for updating the dispatch orders sheet.
         Email alert is sent to customer mentioning that the order has been dispatched.
- step 4 : Conveyor belt starts and stops when order is reached at the side of ur5-2
- step 5 : Ur5-2 finds gets the colour of the package, finds out its position and then places them in approriate bin. It then sends request to
         update the shipped orders to ROS-IOT Bridge. Email alert is sent to customer mentioning that the order has been Shipped.
- step 6 : Website giving details about the orders is updated.
<br><br>

**These steps are repeated for all the orders till they are shipped.**
    

       

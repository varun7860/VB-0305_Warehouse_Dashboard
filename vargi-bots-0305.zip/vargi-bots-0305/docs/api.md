# API documentation.

The API documentation consists of two main sections "Nodes" and "modules". The Nodes consist of 
ROS-Nodes that are used in this project.The modules section consist of IOT module which is used in 
this project. Below is the heirarchy of API documentation :

                        ---------------Automated Warehouse-------------------
                        |                                                   |
                        |                                                   |
                     ROS-Nodes                                             Modules
                        |                                                   |
                        |                                                   |
           ----------------------------                                    IOT Module
           |        |        |        |
           |        |        |        |
          Ur5-1   Ur5-2    IOT-ROS   Conveyor
                            Bridge   controller.


                                                    


## ROS-Nodes

The Ros nodes consist of 4 main nodes : UR5-1 , UR5-2 , ROS-IOT Bridge and Conveyor controller which all will be 
explained in detail in their individual sections. Below are the basic functions of these nodes:

- UR5-1 : Manages dispatching of orders
- UR5-2 : Manages shipping of the orders
- ROS-IOT Bridge: communicates with ROS-nodes and pushes the data in the spreadsheets.
- Conveyor Controller: Controls the conveyor belt.

### UR5-1 Node.

This is the script responsible for controlling `Ur5_1 arm`. ` Ur5_1` arm
picks the package from the shelf and places them on the conveyor belt
After this, `ur5_1` arm node sends the request to update the dispatch
orders sheet to ROS-IOT Bridge server.Basically, this node is
responsible for Dispatching of the orders. Given below is the cheatsheet of
this node.

```
 ______________________________________________________________________
|
|This node contains following classes and functions:
|
| Classes
| -------
| Ur51 : object
|     - Used to control the ur5_1 Robot.
|
| Camera2D : object
|     - Used to detect colour of the packages present on the shelf.
|
| Gripper1 : object
|     - Used to control the gripper of ur5 1 arm.
|
|......................................................................
|
| Functions
| ---------
| callback_1 : msg
|     - A callback function for topic >> /eyrc/vb/camera_1/image_raw
|
| callback_2 : msg
|     - A callback function for topic >> /ros_iot_bridge/mqtt/sub
|
| main :
|     - Main function of the script.
|______________________________________________________________________
```

#### Classes of UR5-1 Node.

All the classes of ur5-1 node and their methods are explained in detail below:


1. `Class ur51(object): Controls Ur5-1 robot`

```
     __________________________________________________________________
    |
    | Description
    | -----------
    | - This class controls ur5_1 Arm in various ways like going from
    |   one position to another using joint angles, geometry_msgs.pose
    |   and predefined positions.
    |
    | .................................................................
    |
    | Attributes
    | ----------
    |   None
    |
    |..................................................................
    |
    | Methods
    | -------
    |
    | set_joint_angles(arg_list_joint_angles)
    |                   - To make ur5-1 go from one position to another
    |                     using joint angles.
    |
    | go_to_predefined_pose(arg_pose_name)
    |                   - To make ur5-1 go from one position to another
    |                     using predefined pose names.
    |
    | update_dispatched_orders_sheet(order_id)
    |                   - To send request to IOT-ROS bridge server to
    |                     update dispatched orders spreadsheet.
    |
    | get_all_boxes()
    |                   - Provides the list of all packages present.
    |
    | wait_for_state_update(package_name,box_is_known=False,
    |                       box_is_attached=False,timeout=4)
    |                   - For successful operations on packages in Rviz
    |
    | add_rviz_boxes(package_list)
    |                   - Adds the required packages in rviz
    |
    | add_box(self, package_name, timeout=4)
    |                   - Adds a box in rviz
    |
    | attach_box(package_name, timeout=4)
    |                   - Attaches the box to gripper in rviz.
    |
    | detach_box(package_name, timeout=4)
    |                   - Detaches gripper in rviz
    |
    | remove_box(package_name, timeout=4)
    |                   - Removes box from the rviz planning scene.
    |
    | arrange_order_details(self, dictionary)
    |                   - Arranges the order list in a specific order.
    |
    | get_hp_package_name(self)
    |                   - Gets the name of HP package from remaing
    |                     HP packages
    |
    | get_mp_package_name(self)
    |                   - Gets the name of MP package from remaing
    |                     MP packages
    |
    | get_lp_package_name(self)
    |                   - Gets the name of LP package from remaing
    |                     LP packages
    |
    | get_pending_orders(self)
    |                   - Gives a list of remaining orders.
    |
    | package_type(self, priority)
    |                   - Finds out the priority of the package.
    |
    | update_pending_orders(key, value)
    |                   - Updates the pending orders.
    |
    | update_hp_orders_dispatched(order_id)
    |                   - Updates the list of HP orders that have been
    |                     dispatched.
    |
    | update_mp_orders_dispatched(order_id)
    |                   - Updates the list of MP orders that have been
    |                     dispatched.
    |
    | update_lp_orders_dispatched(order_id)
    |                   - Updates the list of LP orders that have been
    |                     dispatched.
    |
    | check_for_hp_orders()
    |                   - Checks for the presence of HP orders
    |
    | check_for_mp_orders()
    |                   - Checks for the presence of MP orders
    |
    | check_for_lp_orders()
    |                   - Checks for the presence of LP orders
    |
    |__________________________________________________________________
```


##### Methods of Ur51 Class.

 - `set_joint_angles(arg_list_joint_angles)`:

         ______________________________________________________________
        |
        | Description
        | -----------
        | - This function is used to set joint angles of UR5 Arm using
        |   list of joint angles.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | arg_list_joint_angles : list -> float
        |          - list containing set of joint angle values in float
        |
        |..............................................................
        |
        | Returns
        | -------
        | flag_plan : bool
        |     - True >> If execution was successful.
        |     - False >> If execution failed.
        |______________________________________________________________


 - `go_to_predefined_pose(self, arg_pose_name)`:

         ______________________________________________________________
        |
        | Description
        | -----------
        | - Makes the arm go to a position already defined in Moveit
        |   setup assistant.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | arg_pose_name : str
        |          - Desired position name in string format.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `get_all_boxes()`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Gives the list of all packages present in the warehouse.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        |   None
        |
        |..............................................................
        |
        | Returns
        | -------
        |  list
        |    - List of string format containing names of all packages.
        |______________________________________________________________

- `wait_for_state_update(name, box_is_known=False, box_is_attached=False, timeout=4)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Use for successful operations on package by Rviz.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | name : str
        |          - Name of the package in string format.
        |
        | box_is_known : bool -> optional
        |          - status of box in planning scene. if not passed
        |            default value will be set to False.
        |
        | box_is_attached : bool -> optional
        |          - attach status of box in planning scene. If not
        |            passed default value will be set to False.
        |
        | timeout : int -> optional
        |          - Sets the timout period. If not passed then the
        |            default value be set to 4.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  bool
        |     - True if  box is attached and placed in planning scene.
        |     - False if box is not attached and placed in scene.
        |______________________________________________________________


 - `add_rviz_boxes(package_list)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Add all the required packages in planning scene of Rviz.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | package_list : list -> str
        |          - list of all package names in string format..
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `add_box(package_name, timeout=4)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Adds a single package/box in Rviz.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | package_name: str
        |          - A name of package in string format.
        |
        | timeout : int -> optional
        |          - Sets the timout period. If argument not given then
        |            default value of 4 will be set.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  bool
        |     - True if box was successfully added in the scene.
        |     - False if there was a timeout problem and box doesn't
        |       get added.
        |______________________________________________________________



 - `attach_box(self, package_name, timeout=4)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Attaches the package to ur5_1 arm in Rviz planning scene.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | package_name: str
        |          - A name of package in string format.
        |
        | timeout : int -> optional
        |          - Sets the timout period. If argument not given then
        |            default value of 4 will be set.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  bool
        |     - True if box was successfully added in the scene.
        |     - False if there was a timeout problem and box
        |       doesn't get added.
        |______________________________________________________________


 - `detach_box(package_name, timeout=4)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Detaches the package from the ur5_1 arm in Rviz planning.
        |   scene.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | package_name: str
        |          - A name of package in string format.
        |
        | timeout : int -> optional
        |          - Sets the timout period. If argument not given then
        |            default value of 4 will be set.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  bool
        |     - True if box was successfully added in the scene.
        |     - False if there was a timeout problem and box doesn't
        |       get added.
        |______________________________________________________________



 - `remove_box(package_name, timeout=4)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Removes the package from Rviz planning scene.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | package_name: str
        |          - A name of package in string format.
        |
        | timeout : int -> optional
        |          - Sets the timout period. If argument not given then
        |            default value of 4 will be set.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  bool
        |     - True if box was successfully added in the scene.
        |     - False if there was a timeout problem and box doesn't
        |       get added.
        |______________________________________________________________

 - `arrange_order_details(order_details)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - converts the order details in the apppropriate order. All
        |   the details coming from ros-iot bridge will be extracted,
        |   ordered here.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | order_details: <dict>
        |          - A Dictionary of order details.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  dict
        |     - An ordered dictionary is returned.
        |______________________________________________________________


 - `update_dispatch_orders_sheet(order_id)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Sends request to ROS-IOT Bridge to update dispatched orders
        |   list in spreadsheet.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | order_id : str
        |          - order id in string format.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `get_hp_package_name()`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Gives the name of HP package from remaining HP packages.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        |   None
        |..............................................................
        |
        | Returns
        | -------
        |  str
        |    - Name of HP package in string format.
        |______________________________________________________________


 - `get_mp_package_name()`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Gives the name of MP package from remaining MP packages.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        |   None
        |..............................................................
        |
        | Returns
        | -------
        |  str
        |    - Name of MP package in string format.
        |______________________________________________________________


 - `get_lp_package_name()`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Gives the name of LP package from remaining LP packages.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        |   None
        |..............................................................
        |
        | Returns
        | -------
        |  str
        |    - Name of LP package in string format.
        |______________________________________________________________


 - `get_pending_orders()`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Gives the list of pending orders.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        |   None
        |..............................................................
        |
        | Returns
        | -------
        |  list -> str
        |    - list of pending orders with string elements.
        |______________________________________________________________


 - `package_type(priority)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Finds out the content of the package.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | priority : str
        |         - priority type in string format (HP, MP or LP).
        |..............................................................
        |
        | Returns
        | -------
        |  str
        |    - content of the package in string format.
        |______________________________________________________________

 - `update_pending_orders(order_id, value)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Updates the pending orders list.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | order_id : str
        |       - order id in string format.
        |
        | value : str
        |       - value to be set for particular order id.
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `update_order_priority(order_id, value)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Updates the orders with their respective priorities.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | key : str
        |      - order id in string format.
        |
        | value : str
        |      - value to be set for particular order id.
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________

 - `update_hp_orders_dispatched(order_id)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - When any kind of HP order is dispatched it is added to this
        |   list.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | order_id : str
        |          - order id in string format.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `update_mp_orders_dispatched(order_id)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - When any kind of MP order is dispatched it is added to this
        |   list.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | order_id : str
        |          - order id in string format.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________ 


 - `update_lp_orders_dispatched(order_id)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - When any kind of LP order is dispatched it is added to this
        |   list.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | order_id : str
        |          - order id in string format.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `check_for_hp_orders()`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Checks for remaining high priority orders.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        |   None
        |
        |..............................................................
        |
        | Returns
        | -------
        | int
        |     - 0 if orders are not yet to be received.
        |     - 1 if HP order is remaining.
        |     - 2 if no HP order is remaining.
        |
        | str
        |     - oid in string format if HP order is found.
        |     - None if no HP order is found.
        |
        |______________________________________________________________


 - `check_for_mp_orders()`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Checks for remaining medium priority orders.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        |   None
        |
        |..............................................................
        |
        | Returns
        | -------
        | int
        |     - 0 if orders are not yet to be received.
        |     - 1 if MP order is remaining.
        |     - 2 if no MP order is remaining.
        |
        | str
        |     - oid in string format if MP order is found.
        |     - None if no MP order is found.
        |
        |______________________________________________________________
        

 - `check_for_lp_orders(self)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Checks for remaining low priority orders.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        |   None
        |
        |..............................................................
        |
        | Returns
        | -------
        | int
        |     - 0 if orders are not yet to be received.
        |     - 1 if LP order is remaining.
        |     - 2 if no LP order is remaining.
        |
        | str
        |     - oid in string format if LP order is found.
        |     - None if no LP order is found.
        |
        |______________________________________________________________

**`2. Class Camera2D(object): Performs Image processing`**

```
     __________________________________________________________________
    |
    |Description
    |-----------
    |
    | - Class used for image processing and finding the positions of
    |   the package on the shelf.This class is also resposible for
    |   sending messages to ur5_2 regarding package colour and
    |   dispatch details.
    |
    |..................................................................
    |
    | Attributes
    | ----------
    |   None
    |
    |..................................................................
    |
    | Methods
    | -------
    | detect_color(image)
    |             - Detects the colour of the package.
    |
    | get_pose(package_name)
    |             - finds the position of the package in x,y,z axis.
    |
    | get_package_image(image, name)
    |             - Finds the required cropped image of the package.
    |
    | show_image(camera_message)
    |             - Displays the image of packages on the shelf.
    |
    | get_image(camera_image)
    |             - Gives the image in mathematical way(matrix form)
    |
    | send_message(pkg_name, pkg_colour, order_details, oid, publisher)
    |             - Sends the message to ur5_2 node.
    |
    | send_message_to_conveyor(publisher)
    |             - Sends message to conveyor belt controller node.
    |
    |__________________________________________________________________

```

####Methods of Class: Camera2D


 - `detect_color(image)`:

         __________________________________________________________
        |
        |Description
        |-----------
        | - Detects the colour of the required package.
        |
        |...........................................................
        |
        | Parameters
        | ----------
        | image: 2D array(image matrix)
        |          - Cropped image of the package.
        |
        |...........................................................
        |
        | Returns
        | -------
        | self.color : str
        |      - Returns color of package in string format.
        |_____________________________________________________________


 - `get_pose(package_name)`:

         __________________________________________________________
        |
        |Description
        |-----------
        | - Finds the list of joint angles for ur5-1 to reach the
        |   required package on the shelf.
        |
        |...........................................................
        |
        | Parameters
        | ----------
        | package_name: str
        |          - name of the package in string format.
        |
        |...........................................................
        |
        | Returns
        | -------
        | list :
        |      - List of joint angles for ur5-1 to reach that package.
        |_____________________________________________________________

 - `get_package_image(image, name)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Finds the cropped image of the desired package.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | image: 2D Array(image matrix)
        |          - image taken of all the packages on shelf.
        |
        | name: str
        |          - Name of the required package.
        |
        |..............................................................
        |
        | Returns
        | -------
        | 2D Array(image matrix) :
        |      - cropped image of the required package.
        |______________________________________________________________


 - `show_image(camera_message)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Displays the image taken by camera 1.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | camera message : sensors_msgs.msg -> Image.msg format.
        |            - message from camera 1 from the sub callback.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `get_image(camera_message)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Gives the image taken by camera 1.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | camera message : sensors_msgs.msg -> Image.msg format.
        |            - message from camera 1 from the sub callback.
        |
        |..............................................................
        |
        | Returns
        | -------
        | 2D Array(image matrix)
        |           - Image taken of all packages on shelf.
        |______________________________________________________________


 - `send_message(pkg_name, pkg_colour, order_details, oid, publisher)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - publishes the message to ur5-2 node regarding package color
        |   identified by ur5-1 node and dispatch details.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | pkg_name : str
        |            - Name of package in string format
        |
        | pkg_colour : str
        |            - Colour of the package in string format.
        |
        | order_details : list
        |            - list of order details.
        |
        | oid : str
        |            - Order ID in string format.
        |
        | publisher : Publisher object -> /ur5_1/package/details
        |            - ROS Publisher created in the node.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `send_message_to_conveyor(publisher)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - Sends message to conveyor belt to start the belt.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | publisher : Publisher object -> /ur5_1/package/place/response
        |            - ROS Publisher created in the node.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


**`3. Class Gripper1(object): Attaches/Detaches objects.`**

```
     __________________________________________________________________
    |
    | Description
    | -----------
    | - Used for activating or deactivating the gripper of Ur5-1 Arm
    |   depending upon the situation.
    |
    | .................................................................
    |
    | Attributes
    | ----------
    |   None
    |
    |..................................................................
    |
    | Methods
    | -------
    |
    | activate()
    |        - Activating the gripper
    |
    | deactivate()
    |        - Deactivating the gripper           -
    |__________________________________________________________________
```

####Methods of Class : Gripper1

 - `activate()`:

         ______________________________________________________________
        |
        | Description
        | -----------
        | - Activates the gripper of ur5_1 arm.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        |   None
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |
        |..............................................................
        |
        | Exceptions
        | ----------
        | rospy.ServiceException
        |      - If the service gets disconnected or not able to
        |        connect to the service server.
        |______________________________________________________________

 - `Deactivate`:

         ______________________________________________________________
        |
        | Description
        | -----------
        | - Deactivates the gripper of ur5_1 arm.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        |   None
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |
        |..............................................................
        |
        | Exceptions
        | ----------
        | rospy.ServiceException
        |      - If the service gets disconnected or not able to
        |        connect to the service server.
        |______________________________________________________________


### UR5-2 Node

This is the script responsible for controlling `Ur5_2 arm`. ur5_2 arm
picks the package present below the logical camera 2 and places them
in the respective bins (i.e: Red Package in Red Bin, Green Package in
Green Bin and Yellow Package in Yellow Bin).After this, the `ur5_2 arm node`
sends the request to update the shipped orders sheet to ROS-IOT Bridge
server.Basically this node is responsible for shipping of the orders.
Given below is the cheatsheet of this node.

```
 _____________________________________________________________________________________
|
|This Node contains following classes and functions:
|
| Classes
| -------
| Ur52 : object
|     - Used to control the ur5_2 Robot.
|
| TF : object
|     - Used to find the positon of object with respect to another.
|
| Camera : object
|     - Used to detect package below logical camera 2.
|
| Gripper2 : object
|     - Used to control the gripper of ur5 2 arm.
|
| Functions
| ---------
| callback_1 : msg
|     - A subscriber callback function for topic >> /ur5_1/package/color
|
| main :
|     - Main function of the script.
|________________________________________________________________________________________
```
#### Classes of UR5-2 Node.

All the classes of ur5-2 node and their methods are explained in detail below:

**`1. Class UR52: Controls Ur5_2 Arm.`**

```
     _______________________________________________________________________________________
    |
    | Description
    | -----------
    | - This class controls ur5_2Arm in various ways like going from one position to another
    |   using joint angles, geometry_msgs.pose and predefined positions.
    |
    | ......................................................................................
    |
    | Attributes
    | ----------
    |   None
    |
    |.......................................................................................
    |
    | Methods
    | -------
    |
    | ee_cartesian_translation(trans_x, trans_y, trans_z, step_size)
    |                   - To make ur5-2 go from one position to another using linear
    |                     translations.
    |
    | go_to_pose(arg_pose, scale)
    |                   - To make ur5-2 go from one position to another using geometry_msgs.
    |
    |
    | set_joint_angles(arg_list_joint_angles)
    |                   - To make ur5-2 go from one position to another using joint angles.
    |
    | go_to_predefined_pose(arg_pose_name)
    |                   - To make ur5-2 go from one position to another using predefined
    |                     pose names.
    |
    | update_shipped_orders(msg)
    |                   - To send request to IOT-ROS bridge server to update shipped orders
    |                     spreadsheet.
    |_______________________________________________________________________________________
```

##### Methods of Class : Ur52

 - `ee_cartesian_translation(trans_x, trans_y, trans_z, step_size)`:

         __________________________________________________________
        |
        |Description
        |-----------
        | - performs the linear translation required for robot to
        |   go from one position to another -> (x,y,z).
        |
        |...........................................................
        |
        | Parameters
        | ----------
        | trans_x : float
        |          - To translate in x-direction.
        |
        | trans_y : float
        |          - To translate in y-direction.
        |
        | trans_z : float
        |          - To translate in z-direction.
        |
        | step_size : float
        |          - Steps to achieve the linear translation.
        |
        |...........................................................
        |
        | Returns
        | -------
        | Result : bool
        |     - True >> If execution was successful.
        |     - False >> If execution failed.
        |___________________________________________________________


 - `go_to_pose(arg_pose, scale=1.0)`:

         ______________________________________________________________
        |
        |Description
        |-----------
        | - This is used for making UR5 go to particular pose using
        |   geometry_msgs.msg
        |
        |...............................................................
        |
        | Parameters
        | ----------
        | arg_pose : geometry_msgs.msg -> float
        |          - geometry_msg format which consists of float values.
        |
        | scale: float
        |          - If not passed then it value is 1.0 by default.
        |
        |................................................................
        |
        | Returns
        | -------
        | flag_plan : bool
        |     - True >> If execution was successful.
        |     - False >> If execution failed.
        |_________________________________________________________________


 - `set_joint_angles(self, arg_list_joint_angles)`:


         ______________________________________________________________
        |
        |Description
        |-----------
        | - This function is used to set joint angles of UR5 Arm using
        |   list of joint angles.
        |
        |...............................................................
        |
        | Parameters
        | ----------
        | arg_list_joint_angles : list -> float
        |          - list containing set of joint angle values in float.
        |
        |................................................................
        |
        | Returns
        | -------
        | flag_plan : bool
        |     - True >> If execution was successful.
        |     - False >> If execution failed.
        |_________________________________________________________________


 - `go_to_predefined_pose(self, arg_pose_name)`:


         ______________________________________________________________
        |
        |Description
        |-----------
        | - Makes the arm go to a position already defined in Moveit
        |   setup assistant.
        |
        |...............................................................
        |
        | Parameters
        | ----------
        | arg_pose_name : str
        |          - Desired position name in string format.
        |
        |................................................................
        |
        | Returns
        | -------
        |  None
        |_________________________________________________________________


 - `update_shipped_orders(self, msg)`:

         _________________________________________________________________
        |
        |Description
        |-----------
        | - Sends request to ROS-IOT Bridge to update shipped orders
        |   list in spreadsheet.
        |
        |...............................................................
        |
        | Parameters
        | ----------
        | msg : ur5-1.msg -> string
        |          - ur5-1 .msg format message in string type.
        |
        |................................................................
        |
        | Returns
        | -------
        |  None
        |________________________________________________________________


**`2. Class TF(Object): Transforms Frames`**

```
    _________________________________________________________________________
    |
    |Description
    |-----------
    |
    | - Class used for Transforming from one frame of reference to another frame
    |   of reference. In this task it is used for transforming the packagen fram
    |   to ur5-2 gripper frame.
    |
    |..........................................................................
    |
    | Attributes
    | ----------
    |   None
    |
    |.............................................................................
    |
    | Methods
    | -------
    | get_frame_cordinates(arg_frame_1, arg_frame_2)
    |             - transforms the frame 1 with respect to frame 2
    |
    | compute_cartesian_translation(x_1, y_1, z_1, x_2, y_2, z_2)
    |             - finds the required translation for going from
    |               pos-1 to pos-2.
    |
    | get_frame(name)
    |             - Finds the frame name of the arrived package.
    |
    |______________________________________________________________________________

```

##### Methods of Class : TF

 - `get_frame_cordinates(arg_frame_1, arg_frame_2)`:

         __________________________________________________________
        |
        |Description
        |-----------
        | - Finds out the frame 1 cordinates with respect to frame
        |   frame 2 cordinates
        |
        |...........................................................
        |
        | Parameters
        | ----------
        | arg_frame_1: str
        |          - First frame name in string format.
        |
        | arg_frame-2: str
        |          - Second frame name in string format.
        |
        |...........................................................
        |
        | Returns
        | -------
        | self._x : float
        |      - Return position in x axis of object in float format.
        |
        | self._y : float
        |      - Return position in y axis of object in float format.
        |
        | self._z : float
        |      - Return position in z axis of object in float format.
        |_____________________________________________________________


 - `compute_cartesian_translation(x_1, y_1, z_1, x_2, y_2, z_2)`:


         _____________________________________________________________
        |
        | Description
        | -----------
        | - Computes the required translation needed to go
        |   from pos_1 to pos_2.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | x1, y1, z1: float, float, float
        |          - x1: Object 1 position in x-axis
        |          - y1: Object 1 position in y-axis
        |          - z1: Object 1 position in Z-axis
        |
        | x2, y2, z2: float, float, float
        |          - x2: Object 2 position in x-axis
        |          - yy: Object 2 position in y-axis
        |          - z2: Object 2 position in Z-axix
        |
        |...............................................................
        |
        | Returns
        | -------
        | self._x1 : float
        |      - Return Translation in x axis of object in float format.
        |
        | self._y1 : float
        |      - Returns Translation in y axis of object in float format.
        |
        | self._z1 : float
        |      - Return Translation in z axis of object in float format.
        |_________________________________________________________________


 - `get_frame(name)`:


         ______________________________________________________________
        |
        | Description
        | -----------
        | - Gets the frame name for the package arrived on the belt.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | name : str
        |      - Name of the package that has arrived in string format.
        |
        |...............................................................
        |
        | Returns
        | -------
        | self._frame_1: str
        |      - world frame
        |
        | self._frame_2: str
        |      - ur5-2 wrist 3 frame
        |
        | self._frame_3 : str
        |      - Frame name of the arrived package on the belt.
        |________________________________________________________________


 **`3. Class Camera(Object): Detects packages below logical camera.`**

```
     ______________________________________________________________________________________
    |
    | Description
    | -----------
    | - Detects the objects present below the logical camera-2. Can identify more than one
    |   object at a time.
    |
    | ......................................................................................
    |
    | Attributes
    | ----------
    |   None
    |
    |.......................................................................................
    |
    | Methods
    | -------
    |
    | get_pose(self, message)
    |                   - Gets the position of the package.
    |
    | set_box_pos(self, position, orientation)
    |                   - sets the box position with desired position and orientation.
    |
    |
    | package_found(self, message)
    |                   - To make ur5-2 go from one position to another using joint angles.
    |
    |________________________________________________________________________________________

```

##### Methods of Class : Camera


 - `get_pose(message)`:

         ________________________________________________________________
        |
        | Description
        | -----------
        | - Gets the position of the package below logical camera 2
        |
        |.................................................................
        |
        | Parameters
        | ----------
        | message : logical camera 2 .msg file format.
        |      - Message that gives details about the position of package.
        |
        |.................................................................
        |
        | Returns
        | -------
        | self._box_pose: geometry_msgs.msg format.
        |      - if package is present below the camera.
        |
        | None
        |      - if no package is present below logical camera 2
        |
        |___________________________________________________________________


 - `set_box_pos(position, orientation)`:

         ________________________________________________________________
        |
        | Description
        | -----------
        | - Sets the box pose in geometry pose format
        |
        |.................................................................
        |
        | Parameters
        | ----------
        | position : list -> float.
        |      - x, y, z positions list in float format.
        |
        | orientation : list -> float
        |      - x, y, z, w rotations list in float format.
        |
        |.................................................................
        |
        | Returns
        | -------
        | self._box_pose: geometry_msgs.msg format.
        |                     - pose in geometry_msgs format.
        |
        |__________________________________________________________________


 - `package_found(message)`:

         _________________________________________________________________
        |
        | Description
        | -----------
        | - Checks for packages present below logical camera 2.
        |
        |.................................................................
        |
        | Parameters
        | ----------
        | message : logical camera 2 .msg file format
        |      - Message that gives details about the position of package.
        |
        |.................................................................
        |
        | Returns
        | -------
        | self._package: bool
        |            - True >> If package is present below camera and if
        |                      package name exists in warehouse list of
        |                      packages.
        |            - False >> If no package is present below and package
        |                       name does not exist in list of warehouse
        |                       packages.
        |
        | self._package_name: str
        |            - str >> If package exists below camera.
        |            - None >> If no package is present below camera.
        |
        |_________________________________________________________________


**`4. Class Gripper2(Object): Activates/Deactivates the Gripper.`**

```
    ______________________________________________________________________________________
    |
    | Description
    | -----------
    | - Used for activating or deactivating the gripper of Ur5-2 Arm depending upon the
    |   the situation.
    |
    | ......................................................................................
    |
    | Attributes
    | ----------
    |   None
    |
    |.......................................................................................
    |
    | Methods
    | -------
    |
    | activate()
    |        - Activating the gripper
    |
    | deactivate()
    |        - Deactivating the gripper
    |
    |_______________________________________________________________________________________

```

##### Methods of Class : Gripper2

 - `activate()`:

         _________________________________________________________________
        |
        | Description
        | -----------
        | - Activates the gripper of ur5_2 arm.
        |
        |.................................................................
        |
        | Parameters
        | ----------
        |   None
        |
        |.................................................................
        |
        | Returns
        | -------
        |  None
        |
        |.................................................................
        |
        | Exceptions
        | ----------
        | rospy.ServiceException
        |      - If the service gets disconnected or not able to
        |        connect to the service server.
        |_________________________________________________________________


 - `Deactivate()`:

         _________________________________________________________________
        |
        | Description
        | -----------
        | - Deactivates the gripper of ur5_2 arm.
        |
        |.................................................................
        |
        | Parameters
        | ----------
        |   None
        |
        |.................................................................
        |
        | Returns
        | -------
        |  None
        |
        |.................................................................
        |
        | Exceptions
        | ----------
        | rospy.ServiceException
        |      - If the service gets disconnected or not able to
        |        connect to the service server.
        |_________________________________________________________________


### Conveyor Controller Node

`conveyor belt node` starts or stops the belt depending upon the situation. 
When the `ur5_1` places the package the belt the belt is started and when the package reaches 
the position below logical camera 2 the belt is stopped so that the `ur5_2` arm can easily 
pick it. Below is the cheatsheet of the node:

```
 ____________________________________________________________________________________________
|
| **Conveyor belt controller**
| ----------------------------
|
| This is conveyor belt node which starts or stops the belt depending upon the situation. 
| When the ur5_1 places the package the belt the belt is started and when the package reaches 
| the position below logical camera 2 the belt is stopped so that the ur5_2 arm can easily 
| pick it.
|
| The script requires the following necessary modules and message files to be installed within
| the python environment you are running this script in:
|
|  * rospy library: This is a ros library for python.
|  * pkg_vb_sim.msg: This folder should contain the necessary message file named 
|                    LogicalCameraImage.
|  * pkg_vb_sim.srv: This folder should contain the necessary service file named 
|                    ConveyorBeltPowerMsg.
|  * Ur5_2: The ur5_2 script should contain a functioning class named Camera.
|  * Std_msgs.msg: The std_msgs.msg should be installed.
|
|.............................................................................................
|
| This node can be imported as module and contains the following Classes and functions:
|
|  Classes
|  -------
|
|  Conveyor : 
|       - This class controls the conveyor belt with desired speed.
|
|.............................................................................................
|
|  Functions
|  ---------
|
|  callback_1 : msg
|      - A subscriber callback function for topic >> /ur5_1/package/place/response
|
| callback_2 : msg
|      - A subscriber callback function for topic >> /eyrc/vb/logical_camera_2
|
|  main : 
|      - The main function of the script.
|__________________________________________________________________________________________________
```
#### Classes of Conveyor Node.

All the classes of Conveyor node and their methods are explained in detail below:

**`Class : Conveyor: Operates the conveyor belt.`**

```
     ____________________________________________________________________________
    |
    | Description
    | -----------
    | - This Class starts or stops the Conveyor belt depending
    |   upon the requests made by the nodes.Basically this class
    |   is used for controlling the conveyor belt.
    |
    | ............................................................................
    |
    | Attributes
    | ----------
    |
    | self._service_topic : str
    |                   - The service topic to get service from service server node.
    |
    | self._belt: object : Object
    |                   - This will be the object created to access the service.
    |
    |..............................................................................
    | Methods
    | -------
    |
    | start(speed)
    |     - Starts the conveyor belt with desired speed input by the user.
    |
    | stop()
    |     - Stops the conveyor belt
    |_______________________________________________________________________________
```

##### Methods of Class: Conveyor.

 - `start(speed)`:

         __________________________________________________________
        |
        | Description
        | -----------
        | - Starts the conveyor belt
        | 
        | The argument speed needs to be passed to start the
        | the belt. The speed can be anything between 0 and 100.
        | Speed more than 100 cannot be passed here.
        |
        |..........................................................
        |
        | Parameters
        | ----------
        | speed : int
        |     - Required speed of the conveyor belt.
        |
        |..........................................................
        | 
        | Exceptions
        | ----------
        | rospy.ServiceException
        |      - If the service gets disconnected or not able to
        |        connect to the service server.
        |
        | speed Error
        |      - If speed more than 100 is passed as an argument.
        |__________________________________________________________


 - `stop()`:

         __________________________________________________________
        |
        | Description
        | -----------
        | - Stops the conveyor belt
        |
        |..........................................................
        |
        | Parameters
        | ----------
        |   None
        |..........................................................
        | 
        | Exceptions
        | ----------
        | rospy.ServiceException
        |      - If the service gets disconnected or not able to
        |        connect to the service server.
        |__________________________________________________________


### ROS-IOT Bridge Node.

This node takes care of ROS-IOT Communication. When any new
order arrives it is converted into mqtt.msg format and then sent
to `ur5_1` node on topic >> `/ros_iot_bridge/mqtt/sub`. All messages
from ROS-nodes are received via a subscriber callback function from
topic >> `eyrc/ACEGWXYZ/ros_to_iot`. This node uses `iot module` for
HTTP requests and MQTT service. Below is the cheatsheet of this node:

```
 ______________________________________________________________________
|
| **ROS Node - Action Server - ROS-IOT Bridge**
| ---------------------------------------------
|
|This node can contains following classes and functions:
|
| Classes
| -------
| IotRosBridgeActionServer : object
|     - Used for ROS-IOT Communication.
|
|......................................................................
|
| Functions
| ---------
| main :
|     - Main function of the script.
|______________________________________________________________________
```


#### Classes of ROS-IOT Bridge Node.

All the classes of ROS-IOT Bridge node and its's methods are explained in detail below:

**`1. Class IotRosBridgeActionServer(object): IOT-ROS Communication.`**

```
     __________________________________________________________________
    |
    | Description
    | -----------
    | - ROS-IOT Bridge class to connect ROS to internet.
    | .................................................................
    |
    | Attributes
    | ----------
    |   None
    |
    |..................................................................
    |
    | Methods
    | -------
    |
    | ros_iot_callback(msg)
    |        - Receives messages from ROS-nodes.
    |
    | mqtt_sub_callback(client, userdata, message)
    |        - Receives orders from the customers.
    |
    | on_goal(goal_handle)
    |        - Accepts goal if they are valid.
    |
    | process_goal(goal_handle)
    |        - Processes the goal when it's received.
    |
    | on_cancel(self, goal_handle)
    |        - When the goal is cancelled.
    |
    |__________________________________________________________________
```

##### Methods of Class : IotRosBridgeActionServer

 - `ros_iot_callback(msg)`:

         ______________________________________________________________
        |
        | Description
        | -----------
        | - Called when a message is received from a ROS-Node.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | msg : ur5-1.msg -> string
        |          - ur5-1 .msg format message in string type.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `mqtt_sub_callback(client, userdata, message)`:

         ______________________________________________________________
        |
        | Description
        | -----------
        | - Called when an incoming order is received. Its a MQTT
        |   subscription callback.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | client : ur5-1.msg -> string
        |          - ur5-1 .msg format message in string type.
        |
        | userdata : str
        |          - User information in string format.
        |
        | message : .json -> str
        |          - message with json parsing.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `on_goal(goal_handle)`:

         ______________________________________________________________
        |
        | Description
        | -----------
        | - Called when a goal is received.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | goal_handle : mqtt format
        |          - Goal paramters
        |
        |..............................................................
        |
        | Returns
        | -------
        |  int
        |    - 0 if goal is rejected.
        |______________________________________________________________


 - `process_goal(goal_handle)`:

         ______________________________________________________________
        |
        | Description
        | -----------
        | - Processes the goal received from client.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | goal_handle : mqtt format
        |          - Goal parameters
        |
        |..............................................................
        |
        | Returns
        | -------
        |  None
        |______________________________________________________________


 - `on_cancel(goal_handle)`:

         _____________________________________________________________
        |
        | Description
        | -----------
        | - Called when a Action Server receives cancel request.
        |
        |..............................................................
        |
        | Parameters
        | ----------
        | goal_handle : mqtt format
        |          - Goal parameters.
        |
        |..............................................................
        |
        | Returns
        | -------
        |  self.cancelled_id : int
        |          - ID of goal which is to be cancelled.
        |______________________________________________________________


## Modules

The modules section consists of `IOT module` which is used for `HTTP requests` 
and handling MQTT Client.


##### IOT Module

This module allows for performing IOT tasks such as `MQTT` and `HTTP requests`.All the details regarding
`incoming orders`, `dispatched orders`, `shipped orders` and `inventory` are pushed from here.

```
  ____________________________________________________________________________________________________
 |
 | **IOT Module**
 | --------------
 |
 |.....................................................................................................
 |
 | This module requires following libraries to be installed:
 |
 |  * time: Python time library.
 |  * paho mqtt : Python MQTT Library
 |  * requests : Python requests library to make HTTP requests.
 |  * datetime : Python datetime library.
 |
 |....................................................................................................
 |
 | This script is imported as module in IOT server and contains the following functions:
 |
 |  MQTT Functions
 |  --------------
 |
 |  iot_func_callback_sub :- Displays the necessary details about the received message
 |                           from the Customer.
 |
 |  mqtt_subscribe_thread_start :- Connects to MQTT and subscribes to mqtt topic for receiving
 |                                 new messages.
 |
 |  mqtt_publish :- Publishes the message on the mqtt topic.
 |
 |......................................................................................................
 |
 |  HTTP Functions
 |  --------------
 |
 |  update_inventory :- Updates the inventory spreadsheet.
 |
 |  update_orders_sheet : Updates the Incoming Orders spreadsheet.
 |
 |  update_dispatched_orders : updates the Orders Dispatched spreadsheet.
 |
 |  update_shipped_orders : updates the Orders Shipped spreadsheet.
 |
 |  get_dispatch_date_and_time : returns the time at which package is dispatched.
 |
 |  get_shipped_date_and_time : returns the time at which package is shipped as well
 |                              as the estimated date of delivery of the package.
 |______________________________________________________________________________________________________

```

###### IOT : MQTT Functions

 - `iot_func_callback_sub(client, userdata, message)`:

```
     ___________________________________________________
    | 
    | Description
    | -----------
    | - This Function Displays Message regarding details
    |   of the received order.
    |....................................................
    | Parameters
    | ----------
    | client : str
    |      - Name of the client.
    |
    | userdata : str
    |      - Data of the current user.
    |
    | message : json parsing format.
    |      - Incoming orders message.
    |....................................................
    | Returns
    | -------
    |  None
    |_____________________________________________________
```

 - `mqtt_subscribe_thread_start(arg_func, arg_url, arg_port, arg_mqtt_topic, arg_mqtt_qos)`:

```
     ___________________________________________________________________
    |
    | Description
    | -----------
    | - MQTT Subscriber which receives messages from the mqtt topic.
    |
    |...................................................................
    |
    | Parameters
    | ----------
    | arg_func : function
    |       - Name of function to be executed. For example callback...etc.
    |
    | arg_url : str
    |       - A string url of mqtt server.
    |
    | arg_port : int
    |       - Port number of mqtt.
    |
    | arg_mqtt_topic : str
    |       - A string topic of mqtt.
    |
    | arg_mqtt_qos : int
    |       - Sets the quality of service(qos) needed. values can
    |         be 0, 1 or 2. 
    |
    |         qos(0) : The publication is sent but there is no confirmation
    |         qos(1) : Ensures that message is sent atleast once.
    |         qos(2) : reliable and makes sure that message is sent only once.
    |
    |........................................................................
    |
    | Returns
    | -------
    |  None
    |_________________________________________________________________________
```


 - `mqtt_publish(arg_broker_url, arg_broker_port, arg_mqtt_topic, arg_mqtt_message, arg_mqtt_qos)`:

```
     ____________________________________________________________________________
    |
    | Description
    | -----------
    | MQTT Publisher that publishes on desired mqtt topic
    |
    |............................................................................
    |
    | Parameters
    | ----------
    | arg_broker_url : str
    |            - A string url of mqtt broker.
    |
    | arg_broker_port : int
    |            - A int port of the broker
    |
    | arg_mqtt_topic : str
    |            - A string topic of mqtt
    |
    | arg_mqtt_message : msgMqttSub
    |            - .msg file of mqtt message format.
    |
    | arg_mqtt_qos : int
    |            - Sets the quality of service(qos) needed. values can
    |              be 0, 1 or 2. 
    |
    |              qos(0) : The publication is sent but there is no confirmation
    |              qos(1) : Ensures that message is sent atleast once.
    |              qos(2) : reliable and makes sure that message is sent only once.
    |
    |...............................................................................
    |
    | Returns
    | -------
    | int
    |   - (0) if the message is successfully published.
    |   - (-1) if any exception occurs or message is not published.
    |_________________________________________________________________________________
```

###### IOT : HTTP Functions

 - `update_inventory()`:

```
     __________________________________________________________________
    | 
    | Description
    | -----------
    | - This function pushes the information about the packages
    |   of the warehouse in the inventory sheet. This function updates
    |   the status of packages every month in the warehouse. For example
    |   if the month is february the SKU number of the package will be
    |   will be formed using the month number 02. For March it will be
    |   03 and so on.
    |
    |..................................................................
    |
    | Parameters
    | ----------
    | Url : str
    |   - The spreadsheet url on which data is to be pushed.
    |
    |....................................................................
    | 
    | Returns
    | -------
    |  None
    |_____________________________________________________________________ 
```

- `get_dispatch_date_and_time()`:

```
     ____________________________________________________________________
    |
    | Description
    | -----------
    | - This function is used to get dispatch date and time of the order.
    |
    |....................................................................
    |
    | Parameters
    | ----------
    |   None
    |
    |....................................................................
    |
    | Returns
    | -------
    | dispatch date and time : str
    |   - A string of dispatch date and time in y/m/d h/m/s format.
    |___________________________________________________________________
```

 - `get_shipped_date_and_time(priority)`:

```
     ____________________________________________________________________
    |
    | Description
    | -----------
    | - This function is used to get the shipping time and estimated time
    |   of delivery of the order.
    |
    |....................................................................
    |
    | Parameters
    | ----------
    | priority : str
    |     - The priority of the order. The priority can HP, MP or LP.
    |
    |....................................................................
    |
    | Returns
    | -------
    | shipped date and time : str
    |     - A string of shipping date and time in y/m/d h/m/s format.
    |
    | estimated delivery date: str
    |      - A string of estimated delivery date in y/m/d format.
    |_____________________________________________________________________
```

 - `update_orders_sheet(dictionary, url)`:

```
     _________________________________________________________
    |
    | Description
    | ------------
    | - This function pushes the data in the Incoming Orders
    |   Spreadsheet.
    |
    |.........................................................
    |
    | Parameters
    | ----------
    | order_details : <dict>
    |    - A dictionary of order details should be passed here.
    |
    | url : str
    |    - A string of spreadsheet url should be passed here.
    |
    |..........................................................
    |
    | Returns
    | -------
    |  None
    |__________________________________________________________
```

 - `update_dispatched_orders(msg, url)`:

```
     _______________________________________________________
    |
    | Description
    | -----------
    | - This function pushes data in the dispatched orders 
    |   spreadsheet.
    |
    |.......................................................
    | 
    | Parameters
    | ----------
    | msg : Ros Ur5_1 .msg -> str.
    |    - A .msg file containing all string data elements.
    |
    | url : str
    |    - A string url of IMS spreadsheet.
    |
    |.......................................................
    |
    | Returns
    | -------
    |  None
    |________________________________________________________
```

 - `update_shipped_orders(msg, url)`:

```
     _____________________________________________________
    |
    | Description
    | -----------
    | - This function pushes data in the shipped orders
    |   spreadsheet.
    |
    |.....................................................
    | 
    | Parameters
    | ----------
    | msg : Ros Ur5_1 .msg -> st
    |    - A string url of IMS spreadsheet.
    |
    | url : str
    |    - A string url of IMS Spreadsheet.
    |
    |.....................................................
    |
    | Returns
    | -------
    |  None
    |______________________________________________________
```

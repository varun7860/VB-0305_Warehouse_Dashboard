# About Vargi Bots

<img src="https://portal.e-yantra.org/img/theme_image/theme_vb.png" width="577" height="555"/>


This project is all about a warehouse management system which consist of two robots that autonomously dispatch and ship orders they get 
from the customers. All customers are notified via the email when the order is dispatched and shipped.A Customers
can track their orders via a synamic interactive dashboard website. Check out the API Documentation and implementation 
to know more about this project.

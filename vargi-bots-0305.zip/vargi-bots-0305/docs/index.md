# Welcome to Vargi-Bots-305

This project was made as a part of Eyantra Robotics Competition (eYRC:2020-2021) based on Vargi bots theme.
This project is based on numerous concepts such as:

- **Robotic Operating System (ROS).**
- **Python.**
- **Google app Scripting.**
- **Image Processing.**
- **Robotic Manipulation.**
- **Robotic Perception.**
- **3D Simulation.**
- **Kinematics.**
- **HTML/Javascript.**

## Commands

* `mkdocs new [dir-name]` - Create a new project.
* `mkdocs serve` - Start the live-reloading docs server.
* `mkdocs build` - Build the documentation site.
* `mkdocs help` - Print this help message.

## Project layout

    pkg_task5/
             bag_files/
                       -`t5.bag`

             config/
                    -`task5_ur5_1.scene`
                    -`task5_ur5_2.scene`

             include

             launch/
                    -`task5_solution.launch`


             msg/
                 -`ur5_1.msg`


             scripts/
                     -`ur5_1.py`
                     -`ur5_2.py`
                     -`conveyor_belt_controller.py`
                     -`getting_order.py`

             src

             package.xml
             CMakeLists.txt


    pkg_ros_iot_bridge/
                       action/
                              -`msgRosIot.action`

                       config/
                              -`config_pyiot.yaml`

                       include

                       launch

                       msg/
                           -`msgMqttSub.msg`

                       scripts/
                               -`node_action_server_ros-iot_bridge.py`

                               pyiot/
                                     -`iot.py`


                       src

                       package.xml

                       CMakeLists.txt



             

             
                    
             

# Introduction
The main goal of task5 was to show the complete demonstration of the Warehouse Management System. Doing this was not an easy task but finally after days of dedicated hardwork I was able to achieve the goal of this task. The main objectives of this task are given below:

- sort the packages based on incoming customer orders
- After sorting push the dispatched and shipped details of the order into their
  respective spreadsheets.
- Updating the dashboard website based on order status.
- Sending emails to customers after dispatching or shipping of orders.
- If multiple orders are remaining for processing then HP orders should be sorted first, then MP
  and then LP orders.

I achieved these goals by couple of steps given below:

1. Made UR5-Node to receive the incoming orders and sort the packages based on that.
2. Made UR5-2 Node to sort the packages.
3. Made Conveyor belt controller node to start/stop the belt.
4. Made IOT module for HTTP requests and making MQTT Client.
5. Sent emails to customers using google apps script
6. Hosted dashboard website on github using javascript.

With these 6 important steps I was easily able to achieve all the goals of task 5.


#Demonstration Video

This is the demonstration video of our performed task which shows the following things:

- **Ur5_1 dispatching packages**
- **Ur5-2 shipping packages**
- **Live data pushed into inventory sheet**
- **Live data pushed into OrdersDispatched sheet**
- **Live data pushed into IncomingOrders sheet**
- **Live data pushed into OrdersShipped sheet**
- **Live updating of dashboard website as well as the sheet.**

<iframe width="560" height="315" src="https://www.youtube.com/embed/jPN8phB5-A0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<br>